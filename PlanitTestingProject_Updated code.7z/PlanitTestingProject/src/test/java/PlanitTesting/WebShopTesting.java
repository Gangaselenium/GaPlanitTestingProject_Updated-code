package PlanitTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.DemoWebShop.Utilis.BrowseFactory;

public class WebShopTesting  {
	
	public WebDriver driver;
	
	
		
		@Test
		public void Test1(){
			
			driver=BrowseFactory.startAppln(driver,"Chrome");
			
			System.setProperty("WebDriver.chrome.driver","D:\\Selenium eclips storage location\\SELENIUM JAVA QA PLANET\\SELENIUM JAVA QA PLANET\\PlanitTestingProject\\chromedriver.exe");
			
			//1)1.      Navigate to URL : http://demowebshop.tricentis.com/
			
			
			
			driver.get("http://demowebshop.tricentis.com/");
			
		// 2.      Click on Login button
			
			driver.findElement(By.xpath("//a[@href='/login']")).click();

		//  3.      Validate “Welcome, Please Sign In!” message
			
	WebElement Validatetext=driver.findElement(By.xpath("//h1[text()='Welcome, Please Sign In!']"));
			
			
			// validating actual and expected
			String expecterdtext="Welcome, Please Sign In!";
			
			String actualtext=Validatetext.getText();
			
			Assert.assertEquals(actualtext, expecterdtext);
			
			System.out.println(Validatetext.getText());
			
		
		// 4.      Log in with given credentials
	driver.findElement(By.xpath("//input[@id='Email']")).sendKeys("atest@gmail.com");
			
			driver.findElement(By.xpath("//input[@id='Password']")).sendKeys("123456");
			
			driver.findElement(By.xpath("//input[@value='Log in']")).click();
			
			
		// 5.      Validate the user account ID on top right
			// 5.      Validate the user account ID on top right
			
		    WebElement emailId=driver.findElement(By.xpath("//div[@class='header-links']//a[@class='account']"));
				
				
				// validating actual and expected
				String expectedId="atest@gmail.com";
				
				String actualId=emailId.getText();
				
				Assert.assertEquals(actualId,expectedId);
				
				System.out.println(emailId.getText());
				
				// 6.      Clear the shopping cart.
				driver.findElement(By.xpath("//span[normalize-space()='Shopping cart']")).click();
				
				// clear click checkbox
			//	driver.findElement(By.xpath("//table[@class='cart']/tbody/tr/td[1]")).click();
				
			//	driver.findElement(By.xpath("//input[@name='updatecart']")).click();
				
			//	System.out.println(driver.findElement(By.xpath("//div[@class='page-body']")).getText()); 
				
			//7.      Select “Books” from Categories
			
				driver.findElement(By.xpath("//ul[@class='top-menu']/li[1]/a")).click();
				
			// 8.      Select a book from the list displayed
				
				driver.findElement(By.xpath("//select[@id='products-viewmode']/option[2]")).click();
				
				
				
		// 9.      Get the price details and enter the quantity (more than one)
				
				driver.findElement(By.xpath("//a[text()='Computing and Internet']")).click();
				
				driver.findElement(By.xpath("//input[@id='addtocart_13_EnteredQuantity']")).clear();
				
				driver.findElement(By.xpath("//input[@id='addtocart_13_EnteredQuantity']")).sendKeys(Keys.CLEAR);
				
				driver.findElement(By.xpath("//input[@id='addtocart_13_EnteredQuantity']")).sendKeys("6");
				
				
	//  10.   Click on “Add to cart”
				
				driver.findElement(By.xpath("//input[@id='add-to-cart-button-13']")).click();

	// 11.   Validate “The product has been added to shopping cart” message
				
				System.out.println(driver.findElement(By.xpath("//p[@class='content']")).getText());
				
	//12.   Click on “shopping cart” on top right and validate the “Sub-Total” Price for selected book.
				
				
				driver.findElement(By.xpath("//a[@class='ico-cart']")).click();
				
				System.out.println(driver.findElement(By.xpath("//table[@class='cart-total']/tbody/tr[4]")).getText());
				
				
				driver.findElement(By.xpath("//li[@id='topcartlink']")).click();	
				
				
				driver.findElement(By.xpath("//input[@id='termsofservice']")).click();
				
				
	//13.   Click on “Check-out”
				
				//checkbox
				driver.findElement(By.xpath("//button[@id='checkout']")).click();
				
				
	//14.   Select “New Address” From “Billing Address” drop down.
				
				WebElement list=driver.findElement(By.xpath("//select[@id='billing-address-select']"));
				


			Select sel=new Select(list);
			sel.selectByVisibleText("New Address");
			
	// 15.   Fill all mandatory fields in “Billing Address” and click “Continue”
			
			driver.findElement(By.id("BillingNewAddress_FirstName")).sendKeys("atest");
			
			driver.findElement(By.id("BillingNewAddress_LastName")).sendKeys("ztest");
			
			
			driver.findElement(By.xpath("//input[@id='BillingNewAddress_Email']")).clear();
			driver.findElement(By.xpath("//input[@id='BillingNewAddress_Email']")).sendKeys("mTest@gmail.com");
			
			WebElement country=driver.findElement(By.id("BillingNewAddress_CountryId"));
			Select se11=new Select(country);
			se11.selectByValue("41");
			
			
			
			driver.findElement(By.id("BillingNewAddress_City")).sendKeys("HYD");
			
			driver.findElement(By.id("BillingNewAddress_Address1")).sendKeys("Address1");
			driver.findElement(By.id("BillingNewAddress_ZipPostalCode")).sendKeys("546");
			
			driver.findElement(By.xpath("//input[@id='BillingNewAddress_PhoneNumber']")).clear();
			driver.findElement(By.xpath("//input[@id='BillingNewAddress_PhoneNumber']")).sendKeys("5643456");
			
			// click “Continue”
			
			// //div[@class='buttons' and@id='billing-buttons-container']//input
			
			driver.findElement(By.xpath("//input[@type='button' and @onclick='Billing.save()']")).click();
			
		//	16.   Select the “Shipping Address” as same as “Billing Address” from “Shipping Address” drop down and click on “Continue”.

		//	Select “New Address” From “Billing Address” drop down.
			
			WebElement list1=driver.findElement(By.xpath("//select[@id='shipping-address-select']"));
			


		Select sel3=new Select(list1);
		sel3.selectByVisibleText("New Address");
	//“Shipping Address” drop down and click on “Continue”.

		driver.findElement(By.id("ShippingNewAddress_FirstName")).sendKeys("atest");
		
		driver.findElement(By.id("ShippingNewAddress_LastName")).sendKeys("rtyyrr");
		
		
		driver.findElement(By.id("ShippingNewAddress_Email")).clear();
		driver.findElement(By.id("ShippingNewAddress_Email")).sendKeys("attp@gmail.com");
		
		
		WebElement countryn=driver.findElement(By.id("ShippingNewAddress_CountryId"));
		Select se22=new Select(countryn);
		se22.selectByValue("4");
		
		
		driver.findElement(By.id("ShippingNewAddress_City")).sendKeys("BNG");
		
		driver.findElement(By.id("ShippingNewAddress_Address1")).sendKeys("atest");
		driver.findElement(By.id("ShippingNewAddress_ZipPostalCode")).sendKeys("2345");
		driver.findElement(By.id("ShippingNewAddress_PhoneNumber")).sendKeys("354785969");
		
		
//		driver.findElement(By.xpath("//input[@id='PickUpInStore']")).click();
		
		driver.findElement(By.xpath("//input[@onclick='Shipping.save()']")).click();
		
	//17.   Select the shipping method as “Next Day Air” and click on “Continue”
		
		driver.findElement(By.xpath("//input[@id='shippingoption_1']")).click();
		
		driver.findElement(By.xpath("//input[@onclick='ShippingMethod.save()']")).click();
		
		
	//18.   Choose the payment method as COD (Cash on delivery) and click on “Continue”
		
		driver.findElement(By.xpath("//input[@onclick='PaymentMethod.save()']")).click();
		
	//19.   Validate the message “You will pay by COD” and click on “Continue”
		
		
		System.out.println(driver.findElement(By.xpath("//p[text()='You will pay by COD']")).getText());
		
		
		driver.findElement(By.xpath("//input[@onclick='PaymentInfo.save()']")).click();
		
	//20.   Click on “Confirm Order”
		
		driver.findElement(By.xpath("//input[@onclick='ConfirmOrder.save()']")).click();
		
	//21.   Validate the message “Your order has been successfully processed!” and print the Order number
		
		System.out.println(driver.findElement(By.xpath("//div[@class='title']")).getText());
		
	//Click on “Continue” and log out from the application 
		
		driver.findElement(By.xpath("//input[@class='button-2 order-completed-continue-button']")).click();
		
		// log out
		driver.findElement(By.xpath("//a[@class='ico-logout']")).click();
		
		
		
		

	}
		
		@AfterClass
		public void tearDown() {
			if(driver!=null) {
				System.out.println("Closing chrome browser");
				driver.quit();
			}}
		
		}



		




