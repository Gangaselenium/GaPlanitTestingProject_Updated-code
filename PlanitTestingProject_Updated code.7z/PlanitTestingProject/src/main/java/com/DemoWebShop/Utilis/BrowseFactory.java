package com.DemoWebShop.Utilis;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowseFactory {
	
	public WebDriver driver;
	
	public static  WebDriver startAppln(WebDriver driver,String BrowserName){
		
		
		 if(BrowserName.equals("Chrome")){
			
			System.setProperty("WebDriver.chrome.driver","D:\\Selenium eclips storage location\\SELENIUM JAVA QA PLANET\\SELENIUM JAVA QA PLANET\\PlanitTestingProject\\chromedriver.exe");
			
			driver=new ChromeDriver();
			
			
			
		}
		else if(BrowserName.equals("Firefox")){
			
		}
		else{
			
			System.out.println("we don't support this broser");
		}
		 
		 driver.manage().window().maximize();
		 driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
		
		 driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		 return driver;
		 
	}
	
	

}
